//
//  ViewController.swift
//  TablesAndPersistences
//
//  Created by Guerrero Azpitarte Adrian on 25/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var names = ["Adrian", "Eduardo", "Cristobal", "Adan", "Alberto", "Abraham", "Juan", "Cristofer", "Casandra", "Fernanda", "Jessica", "Melisa", "Esteban", "Elizaberh", "Triny", "Abraham", "Carlos", "My crush", "Jebber", "Carlitos", "Luis", "Alexis"]
    
    // ya hereda de UIViewController

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { // te manda la posicion actual del RENGLON en la tabla Regresa una celda pintada para que lo devuelva en la tabla
        let cellIdentifier = "celda"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        cell.textLabel?.text = names[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        let cell = tableView.cellForRow(at: indexPath)//dame la celda par ael renglon
        cell?.accessoryType = .checkmark
        
        //---------CREACION DE ALERTA O MENSAJE DE ALERTA
        
        let alertController = UIAlertController(title: "FATAL ERROR", message: "Hola como estas?", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
        
        alertController.addAction(okAction)
        
        present(alertController, animated: true, completion: nil)
    }
    

}

