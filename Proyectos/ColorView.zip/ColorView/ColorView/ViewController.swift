//
//  ViewController.swift
//  ColorView
//
//  Created by Guerrero Azpitarte Adrian on 11/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

//Los metodos que estan aqui se mandan llamar en momentos distintos
// @ Signifcia que es de interface builder y es un Oulet. 
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var switchGreen: UISwitch!
    @IBOutlet weak var switchRed: UISwitch!

    @IBOutlet weak var switchblue: UISwitch!
    
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    
    
    override func viewDidLoad() { // aqui se construyen y ya se instancian todos los elementos.
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Editamos el View
        colorView.layer.borderWidth = 5
        colorView.layer.cornerRadius = 20 //para redondear
        colorView.layer.borderColor = UIColor.black.cgColor//espera un elemento UIcolor
        
        updateControls()
        updateColor()
        
        //CGFloart otro tipo de dato parecido a Double. Sirve para grafica rcolores.
        //Alpha es la transparencia. 1 Activado
    }

    func updateColor(){
        var red: CGFloat = 0 //sabe que es un CGFloat no hace inferencia de tipo. Ya es
        var green: CGFloat = 0
        var blue: CGFloat = 0
        
        if(switchRed.isOn){
            red = CGFloat(redSlider.value) //Devuelve un valor double
        }
        if(switchGreen.isOn){
            green = CGFloat(greenSlider.value) //Devuelve un valor double
        }
        if(switchblue.isOn){
            blue = CGFloat(blueSlider.value) //Devuelve un valor double
        }
        
        colorView.backgroundColor = UIColor(displayP3Red: red, green: green, blue: blue, alpha: 1)
    }
    
    func updateControls(){
    redSlider.isEnabled = switchRed.isOn
    greenSlider.isEnabled = switchGreen.isOn
    blueSlider.isEnabled = switchblue.isOn
    
    }
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        updateControls()
        updateColor()
    }
    
    @IBAction func saliderChanged(_ sender: Any) {
        updateColor()
        
    }
    
    
    @IBOutlet weak var resetBtn: UIButton!
    @IBAction func resetButton(_ sender: Any) {
        redSlider.value = 1
        greenSlider.value = 1
        blueSlider.value = 1
        
        switchRed.isOn = false
        switchGreen.isOn = false
        switchblue.isOn = false
        
        updateControls()
        updateColor()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



//La propiedad oulet permite unicamente modificar items desde el codigo hacia la interfaz.
