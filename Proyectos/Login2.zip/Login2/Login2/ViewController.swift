//
//  ViewController.swift
//  Login2
//
//  Created by Guerrero Azpitarte Adrian on 24/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var usernameTextFiel: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonLoginTap(_ sender: Any) {
        if usernameTextFiel.text == "Azpi" &&
            passwordTextField.text == "azpi"{
            performSegue(withIdentifier: "Welcome", sender: nil)
        }
        else {
            performSegue(withIdentifier: "Fail", sender: nil)
        }
    }
    
}

