//
//  CaptionOption.swift
//  MemeCreator
//
//  Created by Guerrero Azpitarte Adrian on 11/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import Foundation

struct CaptionChoice{
    
}


struct CaptionOption{
    
}
