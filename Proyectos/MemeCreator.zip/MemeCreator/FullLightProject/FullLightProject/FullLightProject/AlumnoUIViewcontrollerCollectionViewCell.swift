//
//  AlumnoUIViewcontrollerCollectionViewCell.swift
//  FullLightProject
//
//  Created by Guerrero Azpitarte Adrian on 17/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class AlumnoUIViewcontrollerCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
