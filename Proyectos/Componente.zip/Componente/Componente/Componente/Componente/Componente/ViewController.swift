//
//  ViewController.swift
//  Componente
//
//  Created by Guerrero Azpitarte Adrian on 18/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var sliderImage: UISlider!
    @IBOutlet weak var image: UIImageView!
    
    let images :[UIImage] = [#imageLiteral(resourceName: "Deathwing_Cataclysm_3"), #imageLiteral(resourceName: "HumanDeathWing"), #imageLiteral(resourceName: "Illidan")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
   //   image.image = UIImage(named: #imageLiteral(resourceName: "HumanDeathWing"))
        
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sliderToChanceImage(_ sender: Any) {
        if sliderImage.value < 0.33{
            image.image = #imageLiteral(resourceName: "Deathwing_Cataclysm_3")
            
        }
            else if sliderImage.value < 0.66{
                image.image = #imageLiteral(resourceName: "HumanDeathWing")
            }
        else if sliderImage.value > 0.67{
            image.image = #imageLiteral(resourceName: "Illidan")
        }

        
    }
    
}
//Declarar rangos
