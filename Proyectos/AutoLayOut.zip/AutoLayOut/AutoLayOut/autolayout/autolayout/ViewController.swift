//
//  ViewController.swift
//  autolayout
//
//  Created by Guerrero Azpitarte Adrian on 11/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var texto: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
            view.backgroundColor = UIColor.purple
    
     /*
        texto.translatesAutoresizingMaskIntoConstraints = false //sirve para limitar los constraints de forma programatica 
        texto.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        texto.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true  */
        
        
        //Activar y habilitar los constroints. Para poder usarlos de foram programatica
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

