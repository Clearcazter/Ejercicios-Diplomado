//
//  SecondViewController.swift
//  UIWindow
//
//  Created by Guerrero Azpitarte Adrian on 25/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func viewWillAppear(_ animated: Bool) {
        print("Will Appear")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print("ViewDidappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("Did disappear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        print("View Will Dissapear")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
   
   
    
  
}
