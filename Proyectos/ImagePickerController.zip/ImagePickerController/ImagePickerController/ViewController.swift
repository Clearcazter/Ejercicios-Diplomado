//
//  ViewController.swift
//  ImagePickerController
//
//  Created by Guerrero Azpitarte Adrian on 25/08/18.
//  Copyright © 2018 Guerrero Azpitarte Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    //El primero para acceder a la galeria y el segundo para pasar de la galeria a la aplicacion
    
    @IBOutlet weak var foto: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func takePhoto(_ sender: UIButton) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self //Se crea un UIImagecontroller para tener acceso a la galeria. Y mi comportamiento se lo voy a dar a self (viewcoNTROLLER)
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            print("Camara disponible")
        }else {
            print("Ahora no hay camara")
            imagePicker.sourceType = .photoLibrary
            present(imagePicker, animated: true, completion: nil)
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
//entrega un diccionario
        if let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
            foto.image = selectedImage
            dismiss(animated: true, completion: nil)
        }
    }
    
}

